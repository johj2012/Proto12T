﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField]
    protected int hp;

    [SerializeField]
    protected float speed;

    [SerializeField]
    protected int ad;

    [SerializeField]
    private GameObject target;

    [SerializeField]
    private Transform self;

    private EState targetCurrentState;
    private EState state;
    


    private BoxCollider2D collider;

    // Start is called before the first frame update
    protected virtual void Start()
    {
        // target = GameObject.FindGameObjectWithTag("Base");
        collider = GetComponent<BoxCollider2D>();
        state = EState.READY;
        speed = 2.0f;
    }

    public void GameStart()
    {
        state = EState.IDLE;
    }

    private void Awake()
    {
        target = GameObject.FindGameObjectWithTag("Base");
        self = gameObject.GetComponent<Transform>();
        //rigid = GetComponent<Rigidbody2D>();
    }
    private void FixedUpdate()
    {
        if (Vector2.Distance(transform.position, target.transform.position) > 3) // 플레이어와 적의 거리가 3 이하가 되면
        {
            transform.position = Vector2.MoveTowards(transform.position, target.transform.position, speed * Time.deltaTime);
            //rigid.velocity = new Vector2(target.position.x, rigid.velocity.y);
        }
        //rotate(self, target.position, rotateSpeed);
        /* var newRotation = Quaternion.LookRotation(transform.position - target.transform.position);
        newRotation.x = 0.0f;
        newRotation.y = 0.0f;*/
    }

    protected void TargetChase()
    {
        if (state != EState.CLEAR)
        {
            targetCurrentState = target.GetComponent<Base>().CurrentState();

            if (targetCurrentState != EState.DEAD && targetCurrentState != EState.READY)
            {
                transform.position = Vector2.MoveTowards(new Vector2(transform.position.x, transform.position.y), target.transform.position, speed * Time.deltaTime);
            }
        }
    }

    public void SetEnemyState(EState newState)
    {
        state = newState;
    }

    public EState currentState()
    {
        return state;
    }

    protected void SetSpeed(float newSpeed)
    {
        speed = newSpeed;
    }

    public int Attack()
    {
        return ad;
    }

    public void GetDamaged(int damaged)
    {
        if (hp - damaged > 0)
        {
            hp -= damaged;
            Debug.Log("Get Damaged!");
        }
        else
        {
            Dead();
        }
    }

    public void Dead()
    {
        // 죽는 애니메이션 재생
        Destroy(this.gameObject);
    }

    // Update is called once per frame
    virtual protected void Update()
    {

    }
}
