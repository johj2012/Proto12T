﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;


public class Slot : MonoBehaviour //, IBeginDragHandler, IDragHandler, IEndDragHandler, IDropHandler
{ 
    [HideInInspector]
    public ItemProperty item;
    public UnityEngine.UI.Image image;

    private Base player;

    private void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Base").gameObject.GetComponent<Base>(); // 플레이어의 재화 정보를 update로 가져와서 활성화 할 아이템 구분
    }

    public void SetItem(ItemProperty item)
    {
        this.item = item;

        if(item==null)
        {
            image.enabled = false;
            
            gameObject.name = "Empty";
            
            gameObject.GetComponent<Image>().enabled = false;
        }
        else
        {
            var text = this.gameObject.transform.GetChild(1).gameObject.GetComponent<Text>();
            text.text = item.cost.ToString();
            image.enabled = true;
            image.sprite = item.sprite;

            gameObject.name = item.name;

            gameObject.GetComponent<Image>().enabled = true;         
        }
    }

    private void Update()
    {
        // 6. 상점 스크립트에서 update문으로 현재 가진 재화보다 비싼 아이템 비활성화 시키기
    }
}
