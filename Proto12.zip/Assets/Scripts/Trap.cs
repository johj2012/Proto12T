﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Trap : MonoBehaviour
{
    [SerializeField]
    protected int recycleNum = 1; // 아이템 사용 횟수

    protected Vector3 trapPosition; // 트랩이 설치된 타일셀 위치

    protected Grid gd;
    protected Tilemap tilemap;
    


    // Start is called before the first frame update
    protected virtual void Start()
    {
        gd = GameObject.FindGameObjectWithTag("Grid").GetComponent<Grid>();
        tilemap = GameObject.FindGameObjectWithTag("TilePath").GetComponent<Tilemap>();

    }

    // Update is called once per frame
    protected virtual void Update()
    {
        
    }
}
