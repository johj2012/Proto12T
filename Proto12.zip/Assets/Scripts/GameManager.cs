﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EState
{
    READY,
    IDLE,
    DAMAGED,
    DEAD,
    CLEAR,
    GAMEOVER
}

public class GameManager : MonoBehaviour
{
    private GameObject player;
    private GameObject[] enemy;

    private float timer;

    private GameObject gameOver; // gameOver UI

    [SerializeField] private bool gameStart;


    void Start()
    {
        gameStart = false;
        player = FindObjectOfType<Base>().gameObject;
        enemy = GameObject.FindGameObjectsWithTag("Enemy");
        timer = 180.0f;

        gameOver = GameObject.FindGameObjectWithTag("GameOver");
        
        gameOver.transform.parent.gameObject.SetActive(false); // gameOver UI의 root오브젝트 (Panel) 비활성화
        gameOver.gameObject.SetActive(false);
        // 준비 땅 ui 띄우고 GameStart 함수 호출
    }

    void GameStart()
    {
        player.GetComponent<Base>().GameStart();
        for (int i = 0; i < FindObjectsOfType<Enemy>().Length; i++)
        { 
            enemy[i].gameObject.GetComponent<Enemy>().GameStart();
        }
    }
    private IEnumerator GameOverDelay()
    {
        yield return new WaitForSeconds(3.0f);
    }

    private void GameOver()
    {
        player.GetComponent<Base>().SetPlayerState(EState.GAMEOVER);
        enemy = enemy = GameObject.FindGameObjectsWithTag("Enemy");
        for (int i = 0; i<FindObjectsOfType<Enemy>().Length; i++)
        {
            enemy[i].GetComponentInParent<Enemy>().SetEnemyState(EState.GAMEOVER);
        }
        GameOverDelay();
        gameOver.transform.parent.gameObject.SetActive(true);
        gameOver.gameObject.SetActive(true);
    }

    private float sumDeltaTime = 0;

    void Update()
    {
        timer -= Time.deltaTime;
        if (sumDeltaTime < 1.0)
        {
            sumDeltaTime += Time.deltaTime;
            if (sumDeltaTime >= 1.0)
            {
                gameStart = true;
                GameStart();
            }
        }
        if(player.GetComponent<Base>().CurrentState() == EState.DEAD)
        {
            GameOver();
        }
    }
}
