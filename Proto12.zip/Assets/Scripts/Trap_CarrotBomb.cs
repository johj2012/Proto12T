﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Trap_CarrotBomb : Trap
{
    [SerializeField] private GameObject trap_carrotBomb;
    [SerializeField] private int ad;

    [SerializeField] private bool bomb;

    [SerializeField] private float boundDistance;

    [SerializeField]
    protected CircleCollider2D collider;

    private Animator anim;

    private GameObject[] enemy;


    // Start is called before the first frame update
    protected override void Start()
    {
        base.Start();
        cost = 3;
        ad = 1;
        bomb = false;
        boundDistance = 3.0f;

        gd = GameObject.FindGameObjectWithTag("Grid").GetComponent<Grid>();
        trap_carrotBomb = gameObject;
        collider = gameObject.GetComponent<CircleCollider2D>();
        anim = GetComponent<Animator>();
        gameObject.GetComponent<CircleCollider2D>().radius = 0.64f;

        anim.SetBool("Bomb", false);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("onTrigger");
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Debug.Log("Enemy Check");
            bomb = true;
        } 
    }

    public void PlaceCarrotBomb(Vector3 position)
    {
        Instantiate(trap_carrotBomb, position, Quaternion.identity);
    }

    private void Bomb()
    {
        bomb = false;
        enemy = GameObject.FindGameObjectsWithTag("Enemy");

        for (int i = 0; i <= enemy.Length - 1; i++)
        {
            if (Vector2.Distance(new Vector2(transform.position.x, transform.position.y),
                new Vector2(enemy[i].transform.position.x, enemy[i].transform.position.y)) <= boundDistance)
            {
                enemy[i].GetComponentInParent<Enemy>().GetDamaged(ad);
            }
        }
        Vector3Int trapPos = tilemap.WorldToCell(transform.position);
        tilemap.GetComponent<TileMapInfo>().DestroyTrap(trapPos);
        Destroy(this.gameObject);
    }

    // Update is called once per frame
    protected override void Update()
    {
        if(bomb)
        {
            Bomb();
        }
    }
}
