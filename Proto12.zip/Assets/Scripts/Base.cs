﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Base : MonoBehaviour
{
    // Start is called before the first frame update

    private bool eating;

    [SerializeField] private int costSpeed;
    [SerializeField] private int MaxCost;
    [SerializeField] private int eatingSpeed;
    [SerializeField] private int cost;
    [SerializeField] private int MaxHP;
    [SerializeField] private int currentHP;

    [SerializeField] private Collider2D collider;

    private EState state;

    private Animator anim;

    private void Awake() // 변수 할당
    {
        eating = true;
        eatingSpeed = 1;

        MaxCost = 100;
        cost = 0;

        MaxHP = 3;
        currentHP = MaxHP;

        state = EState.READY;
    }

    void Start()
    {      
        collider = GetComponent<BoxCollider2D>();

        anim = GetComponent<Animator>();
        anim.SetBool("Start", false);
    }

    public void GameStart() // 게임이 시작되면 호출
    {
        state = EState.IDLE;
        anim.SetBool("Start", true);
    }

    private void OnTriggerEnter2D(Collider2D collision) // 적과 닿았을 때 활성화
    {
        Damaged(collision.GetComponentInParent<Enemy>().Attack()); // 플레이어 getDamaged;
        collision.gameObject.GetComponentInParent<Enemy>().Dead(); // 맞닿은 적 사망
    }

    public int GetCost() // 현재 가진 재화를 반환
    {
        return cost;
    }

    private IEnumerator Delay() // 데미지 입은 애니메이션 딜레이 함수
    {
        yield return new WaitForSeconds(3.0f);
        anim.SetBool("Damaged", false);
    }

    private void Damaged(int newDamaged) // 적에게 데미지를 입었을 때 호출
    {
        currentHP -= newDamaged;
        Debug.Log("Player Current HP : " + currentHP);
        if (currentHP <= 0)
        {
            Dead();
        }
        else
        {
            anim.SetBool("Damaged", true);
            StartCoroutine(Delay());
        }
        
    }

    public void SetPlayerState (EState newState) // 플레이어의 상태 갱신
    {
        state = newState;
    }

    public EState CurrentState() // 플레이어의 상태 반환
    {
        return state;
    }

    private void Dead() // 플레이어 사망 시 호출
    {
        anim.SetBool("Dead", true);
        Debug.Log("Player DEAD");
        state = EState.DEAD;
    }

    private float sumDeltaTime = 0.0f;
    
    // Update is called once per frame
    void Update() 
    {
        if (state == EState.IDLE)
        {
            if (cost < MaxCost) // 3초마다 1재화 충전
                {
                sumDeltaTime += Time.deltaTime;
                if (sumDeltaTime >= costSpeed) {
                    cost += 1;
                    sumDeltaTime -= costSpeed;
                }
            }
            else
            {
                state = EState.CLEAR;
            }
        }
    }
}
